# Carnicería Chapala

Sitio web dinámico de Carnicería Chapala: catálogo de productos, sistema de apartado de pedidos, panel de administración (productos, pedidos y empleados) y chat integrado.

## Desarrollo local

Necesitas Node.js y npm — [instalar con nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <url-de-este-repositorio>
cd <nombre-del-repositorio>
npm i
npm run dev
```

## Construido con

- TanStack Start
- TypeScript
- React
- Tailwind CSS
- Supabase
